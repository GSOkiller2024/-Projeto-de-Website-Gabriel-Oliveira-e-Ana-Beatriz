<button id="btn_bscClientes">Preencher</button><br>

<table>

    <thead>

        <tr>

            <th>ID</th>

            <th>NOME</th>

            <th>SOBRENOME</th>

            <th>CPF</th>

            <th>ENDEREÇO</th>

            <th>TELEFONE</th>

            <th>EMAIL</th>

        </tr>

    </thead>

    <tbody id="tblClientes"></tbody>

</table>
