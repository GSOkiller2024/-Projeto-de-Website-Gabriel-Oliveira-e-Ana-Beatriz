<?php

    if(isset($_POST['campo_modelo'])){

        $fabricante = $_POST['campo_fabricante'];

        $processador = $_POST['campo_processador'];

        $RAM = $_POST['campo_RAM'];

        $HD = $_POST['campo_HD'];

        $tela = $_POST['campo_tela'];

        $descricao = $_POST['campo_descricao'];

        $preco = $_POST['campo_preco'];

        $sql = "INSERT INTO computadores(fabricante,processador,memoria_ram,tamanho_do_hd,tamanho_da_tela,descricao,preco)VALUES('$fabricante',$processador','$RAM','$HD','$tela','$descricao''$preco',)";

        include "conexao.php";

        if (mysqli_query($con, $sql)) {

            header("Location:index.php?p=rv");

        }else{

            echo "Erro: " . $sql . "<br>" . mysqli_error($con);

        }

        mysqli_close($con);



    }else{

        echo "erro";

    }

?>
