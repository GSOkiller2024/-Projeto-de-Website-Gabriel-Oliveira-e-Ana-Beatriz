<button id="btn_bscpIMPRESSORA">Preencher</button><br>

<table>

    <thead>

        <tr>

            <th>ID</th>

            <th>NOME DO FABRICANTE</th>

            <th>TIPO DE PROCESSADOR</th>

            <th>MEMORIA RAM</th>

            <th>TAMANHO DO HD</th>|

            <th>TIPO DE IMPRESSÃO</th>

            <th>TIPO DE FUNCIONALIDADE</th>

            <th>DESCRIÇÃO</th>
            
            <th>PREÇO</th>

        </tr>

    </thead>

    <tbody id="tblImpressora"></tbody>

</table>
.