<?php

    if(isset($_POST['campo_tipo'])){

        $fabricante = $_POST['campo_fabricante'];

        $processador = $_POST['campo_processador'];

        $RAM = $_POST['campo_RAM'];

        $HD = $_POST['campo_HD'];

        $funcionalidade = $_POST['campo_funcionalidade'];

        $descricao = $_POST['campo_descricao'];

        $preco = $_POST['campo_preco'];

        $sql = "INSERT INTO computadores(fabricante,processador,memoria_ram,tamanho_do_hd,funcionalidade,descricao,preco)VALUES('$fabricante',$processador','$RAM','$HD','$funcionalidade','$descricao''$preco',)";

        include "conexao.php";

        if (mysqli_query($con, $sql)) {

            header("Location:index.php?p=rv");

        }else{

            echo "Erro: " . $sql . "<br>" . mysqli_error($con);

        }

        mysqli_close($con);



    }else{

        echo "erro";

    }

?>
