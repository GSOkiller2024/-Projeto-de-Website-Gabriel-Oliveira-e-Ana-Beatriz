<?php

    $sql = "SELECT * FROM computadores";

    include "conexao.php";

    $resposta = "";

    if ($resultado = mysqli_query($con, $sql)) {

        while ($lh = mysqli_fetch_assoc($resultado)) {

            $resposta .= "<tr>";

            $resposta .= "<td>".$lh['id_computador']."</td>";

            $resposta .= "<td>".$lh['modelo']."</td>";

            $resposta .= "<td>".$lh['fabricante']."</td>";

            $resposta .= "<td>".$lh['processador']."</td>";

            $resposta .= "<td>".$lh['memoria_ram']."</td>";

            $resposta .= "<td>".$lh['tamanho_do_hd']."</td>";
            
            $resposta .= "<td>".$lh['tamanho_da_tela']."</td>";
           
            $resposta .= "<td>".$lh['descricao']."</td>";

            $resposta .= "<td>".$lh['preco']."</td>";

            $resposta .= "</tr>";

        }

        echo "$resposta";
    }

?>