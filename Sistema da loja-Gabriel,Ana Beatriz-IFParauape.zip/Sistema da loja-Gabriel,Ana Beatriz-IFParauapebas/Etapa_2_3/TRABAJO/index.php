<!DOCTYPE html>

<html lang="en">
<head>

    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="unidade05.css">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

     <style>
        table,th,td{
            border: 1px solid white;
        }

        ul{

            list-style:none;

        }

    </style>

    <title>ELETRONINA</title>
	<script scr="jquery-3.5.1.min.js"></script>
	<script scr="scripts.js"></script>

</head>

<body>

<div class="topo">
        <h1>ELETRONINA</h1>
        <div class="logo">
            <img src="logo.png" width="100" height="100">
        </div>
</div>

<div class="menu">
            <ul>
                <li>
                    <div class="acao_menu"> 
                        <button class="botao_menu">MENU</button>
                        <div class="submenu">

                        <a href="index.php?p=cc">Cadastrar cliente</a>

                        <a href="index.php?p=vc">Ver clientes</a>

                        <a href="index.php?p=cf">Cadastrar funcionário</a>

                        <a href="index.php?p=vf">Ver funcionários</a>

                        <a href="index.php?p=cpc">Cadastrar computador</a>

                        <a href="index.php?p=cip">Cadastrar impressora</a>

                        <a href="index.php?p=vpc">Ver computadores</a>

                        <a href="index.php?p=vip">Ver impressoras</a>

                        <a href="index.php?p=rv">Realizar venda</a>

                        <a href="index.php?p=vv">Ver vendas</a>
                        
                        </div>
                    </div>
                </li>
                <li><a href="login.html">Login</a></li>
                <li><a href="fale_conosco.html">Fale conosco</a></li>
                <input type="search" placeholder="pesquisar..." class="pesquisa">
            </ul>
</div>

<div class="principal">
        <div class="lado">
            <h2>Um pouco sobre nossas tecnologias</h2>
            <h3>Impressoras multifuncionais!</h3>
            <img src="impressora.jpg" height="200px" width="300px" style="margin-left: 75px">
            <br>
            <h3>Marcas variadas</h3>
            <img src="marcas.jpg" height="200px" width="300px" style="margin-left: 75px">
            <br>
            <h3>PC's gamers</h3>
            <img src="gamer.jpg" height="200px" width="300px" style="margin-left: 75px">
            <br>
            <h3>Comprometimento com o meio ambiente</h3>
            <img src="ambiente.jpg" height="200px" width="300px" style="margin-left: 75px">
            <br>
            <h3>Na forma em que voce preferir!</h3>
            <img src="formas.jpg" height="200px" width="300px" style="margin-left: 75px">
            <br>
        </div>

        <div class="centro">
        	<?php

                if(isset($_GET['p'])){

                    $pagina = $_GET['p'];

                }else{

                    $pagina = 'bia';

                }

                if($pagina == 'cc'){

                    include "cliente_form.html";

                }elseif($pagina == 'vc'){

                    include "cliente_ver.php";

                }elseif($pagina == 'cf'){

                    include "funcionario_form.html";

                }elseif($pagina == 'vf'){

                    include "funcionario_ver.php";

                }elseif($pagina == 'cpc'){

                    include "computador_form.html";

                }elseif($pagina == 'vpc'){

                    include "computador_ver.php";

                  }elseif($pagina == 'cip'){

                    include "impressora_form.html";

                }elseif($pagina == 'vip'){

                    include "impressora_ver.php";    

                }elseif($pagina == 'rv'){

                    include "venda_form.html";

                }elseif($pagina == 'vv'){

                    include "venda_ver.php";
                }
            ?>

            <h1>Um pouco sobre nós</h1>
			<br>
			<h3>Sobre a Eletronina</h3>
			<div class="conteudo" style="height: 140px">
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis at arcu ex. Curabitur in ipsum leo. Nulla eu ex aliquet, ornare ex at, pretium augue. In ut molestie risus, quis volutpat dolor. Suspendisse id elementum neque. Etiam in nisl ut purus suscipit porttitor. Curabitur risus lacus, congue ac metus quis, suscipit dapibus leo. Curabitur eget convallis leo. Morbi lobortis eleifend </p>
			</div>
			<br>
			<h3> Quem está por trás da empresa...</h3>
			<div class="conteudo" style="height: 130px">
				<p>Sed fringilla sed tellus non commodo. Fusce pretium risus vel tortor laoreet, a imperdiet ligula aliquam. Suspendisse vitae mauris sit amet dolor consectetur varius id semper ligula. In ut suscipit sapien. Praesent ut ultricies velit. Nullam pellentesque varius nulla. Quisque ullamcorper turpis et tempus mollis.</p>
			</div>
			<h3>Nossa relação com o meio ambiente</h3>
			<div class="conteudo" style="height: 180px">
				<p>	Aenean tortor erat, sollicitudin a sapien in, consequat malesuada libero. Curabitur volutpat nisi non nulla ultrices molestie. Ut pulvinar rhoncus accumsan. Nullam sagittis arcu non ipsum pretium, et dictum est condimentum. Morbi laoreet mi vel sem facilisis ornare. Vivamus eget urna sit amet arcu bibendum tempus. Maecenas in felis et dolor consequat consequat. Vestibulum pharetra malesuada enim, quis elementum metus lacinia vel. Fusce finibus rutrum mi ac auctor. Pellentesque vulputate varius dapibus.
				</p>
			</div>
			<br>
			<h3>Tecnologia de forma sustentável</h3>
			<div class="conteudo" style="height: 148px">
				<p>Nulla luctus ligula eget sem cursus, a facilisis augue sagittis. Pellentesque vel nunc nisl. Nulla facilisi. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Quisque dignissim aliquam auctor. Pellentesque finibus commodo venenatis. Suspendisse lobortis tellus a eros blandit tincidunt. Praesent pellentesque lacus at libero maximus ultrices et at tellus. Etiam tincidunt felis sit amet ultrices cursus.</p>
			</div>

            </div>
        </div>
</div>

    <div class="rodape">
        <h4>Eletronina, a loja on-line mais segura do Brasil!</h4>
    </div>


</body>
</html>