$(document).ready(function () {

    $("#conteudo").on('submit','#frmCliente', function (e) {

        e.preventDefault();

        var formulario = $(this).serialize();

        $.ajax({

            type: "post",

            url: "ins_cliente.php",

            data: formulario,

            dataType: "text",

            success: function (response) {

                if(response == "ok"){

                    $('#frmCliente').each (function(){

                        this.reset();

                    });

                    alert("Cliente inserido com sucesso!");

                }else{

                    alert(response);

                }

            }

        });

    });



    $("#conteudo").on('click','#btn_bscClientes', function (e) {

        e.preventDefault();

        $.ajax({

            type: "post",

            url: "cliente_busca.php",

            data: "buscar",

            dataType: "text",

            success: function (response) {

                $('#tblClientes').html(response);

            }

        });

    });



    $("#conteudo").on('focus','#cmpCl', function (e) {

        e.preventDefault();

        $.ajax({

            type: "post",

            url: "cliente_select.php",

            data: "busca",

            dataType: "text",

            success: function (response) {

                $('#cmpCl').html(response);

            }

        });

    });


 $("#conteudo").on('click','#btn_bscAnimal', function (e) {

        e.preventDefault();

        $.ajax({

            type: "post",

            url: "animal_busca.php",

            data: "busca",

            dataType: "text",

            success: function (response) {

                $('#tblAnimal').html(response);

            }

        });

    });


 $("#conteudo").on('click','#btn_bscFuncionario', function (e) {

        e.preventDefault();

        $.ajax({

            type: "post",

            url: "funcionario_busca.php",

            data: "busca",

            dataType: "text",

            success: function (response) {

                $('#tblFuncionario').html(response);

            }

        });

    });

$("#conteudo").on('click','#btn_bscVenda', function (e) {

        e.preventDefault();

        $.ajax({

            type: "post",

            url: "venda_busca.php",

            data: "busca",

            dataType: "text",

            success: function (response) {

                $('#tblVenda').html(response);

            }

        });

    });


});
