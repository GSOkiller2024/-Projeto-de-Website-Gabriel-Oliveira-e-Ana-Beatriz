<?php

    if(isset($_POST['campo_nome'])){

        $cliente = $_POST['campo_cliente'];

        $funcionario = $_POST['campo_funcionario'];

        $computador = $_POST['campo_computador'];

        $impressora = $_POST['campo_impressora'];

        $data_venda = $_POST['campo_venda'];

        $preco = $_POST['campo_preco'];


        $sql = "INSERT INTO clientes(cliente,funcionario,computador,impressora,data_venda,preco)VALUES('$cliente','$funcionario','$computador','$impressora','$data_venda','$preco')";

        include "conexao.php";

        if (mysqli_query($con, $sql)) {

            header("Location:index.php?p=rv");

        }else{

            echo "Erro: " . $sql . "<br>" . mysqli_error($con);

        }

        mysqli_close($con);



    }else{

        echo "erro";

    }

?>
