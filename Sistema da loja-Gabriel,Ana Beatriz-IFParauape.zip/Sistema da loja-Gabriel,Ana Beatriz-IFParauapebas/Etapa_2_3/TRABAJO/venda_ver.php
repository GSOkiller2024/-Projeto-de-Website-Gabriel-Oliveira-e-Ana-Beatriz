<button id="btn_bscVenda">Preencher</button><br>

<table>

    <thead>

        <tr>

            <th>ID</th>

            <th>CLIENTE</th>

            <th>FUNCIONARIO</th>

            <th>COMPUTADOR</th>

            <th>IMPRESSORA</th>

            <th>DATA DE VENDA</th>

            <th>PREÇO</th>

        </tr>

    </thead>

    <tbody id="tblVenda"></tbody>

</table>
