<?php

    if(isset($_POST['campo_nome'])){

        $nome = $_POST['campo_nome'];

        $sobrenome = $_POST['campo_sobrenome'];

        $cargo = $_POST['campo_cpf'];

        $email = $_POST['campo_endereco'];

        $login = $_POST['campo_telefone'];

        $senha = $_POST['campo_email'];

        $sql = "INSERT INTO clientes(nome,sobrenome,cargo,email,login,senha)VALUES('$nome','$sobrenome','$cargo','$email','$login','$senha')";

        include "conexao.php";

        if (mysqli_query($con, $sql)) {

            header("Location:index.php?p=cf");

        }else{

            echo "Erro: " . $sql . "<br>" . mysqli_error($con);

        }

        mysqli_close($con);



    }else{

        echo "erro";

    }

?>
